---
layout: page
title: Where I've been
permalink: /about/where-ive-been
sitemap: false
# priority: 0.9
---

<div class="generic-page-wrapper">
  <div class="generic-page">
    <iframe class="where-ive-been-map" src="https://www.google.com/maps/d/embed?mid=12KAOn_MJ4U8yiFeILBsA6C2_SFM&hl=en" width="640" height="480"></iframe>
  </div>
</div>
