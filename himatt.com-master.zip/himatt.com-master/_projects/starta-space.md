---
date: 2015-02-20
published: false
title: "Starta Space"
description: "An ongoing project to create site/portfolio building service"
categories: ux, brand, personal
thumbnail: ""

time_period: 2015 onwards

website:
  button_text:
  url: http://starta.space
---
