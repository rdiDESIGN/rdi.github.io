---
date: 2012-08-25
published: true
order_number: 7
title: "Krank"
description: "Block typeface"
categories: on sale, blocky, geometric
thumbnail: "/fonts/krank/flist-krank.svg"
banner: "/fonts/krank/overview.png"
licensetype: Commercial

features:
  - 7 available styles

available_licenses:
  - Web
  - Desktop

supported_languages:

font_weights:
  - "Regular"
  - "Kursiv"
  - "Vibe"
  - "Chisel"
  - "Chisel Duo"
  - "Outline"
  - "Outline Rounded"

vendors:
  - title: "Fontspring"
    licence: Webfont & Desktop
    url: "//www.fontspring.com/fonts/matt-grey-design/krank"

  - title: "Myfonts"
    licence: Webfont & Desktop
    url: "//www.myfonts.com/fonts/matt-grey/krank/"

initial_release: 2012
designed_from: 2012

releases:
  - version: v1.0
    releasedate: Oct 2012
    details: >
      - Released on Myfonts and Fontspring
---

